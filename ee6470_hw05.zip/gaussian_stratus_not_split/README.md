# Sobel Edge Detector

## SystemC Simulation

- make run

## Stratus

- cd stratus
- make sim_all
