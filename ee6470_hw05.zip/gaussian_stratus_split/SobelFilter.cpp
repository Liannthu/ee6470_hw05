#include <cmath>
#ifndef NATIVE_SYSTEMC
#include "stratus_hls.h"
#endif

#include "SobelFilter.h"

SobelFilter::SobelFilter(sc_module_name n) : sc_module(n)
{
#ifndef NATIVE_SYSTEMC
	HLS_FLATTEN_ARRAY(val);
#endif
	SC_THREAD(do_filter);
	sensitive << i_clk.pos();
	dont_initialize();
	reset_signal_is(i_rst, false);

#ifndef NATIVE_SYSTEMC
	//i_rgb.clk_rst(i_clk, i_rst);
	i_r.clk_rst(i_clk, i_rst);
	i_g.clk_rst(i_clk, i_rst);
	i_b.clk_rst(i_clk, i_rst);
	o_result.clk_rst(i_clk, i_rst);
#endif
}

SobelFilter::~SobelFilter() {}

// sobel mask

const int mask[MASK_X][MASK_Y] =
	{
		1, 2, 1,
		2, 4, 2,
		1, 2, 1};

void SobelFilter::do_filter()
{
	{
#ifndef NATIVE_SYSTEMC
		HLS_DEFINE_PROTOCOL("main_reset");
		//i_rgb.reset();
		i_r.reset();
		i_g.reset();
		i_b.reset();
		o_result.reset();
#endif
		wait();
	}
	while (true)
	{
		for (unsigned int i = 0; i < MASK_N; ++i)
		{
			HLS_CONSTRAIN_LATENCY(0, 1, "lat00");
			val[i] = 0;
		}
		unsigned int red = 0.0, green = 0.0, blue = 0.0;
		for (unsigned int v = 0; v < MASK_Y; ++v)
		{
			for (unsigned int u = 0; u < MASK_X; ++u)
			{
				sc_dt::sc_uint<24> rgb;
#ifndef NATIVE_SYSTEMC
				{
					HLS_DEFINE_PROTOCOL("input");
					//rgb = i_rgb.get();
					rgb.range(7, 0) = i_r.get();
					rgb.range(15, 8) = i_g.get();
					rgb.range(23, 16) = i_b.get();
					wait();
				}
#else
				rgb = i_rgb.read();
				

#endif
				unsigned char _red = rgb.range(7, 0);
				unsigned char _green = rgb.range(15, 8);
				unsigned char _blue = rgb.range(23, 16);
				//unsigned char grey = (rgb.range(7, 0) + rgb.range(15, 8) + rgb.range(23, 16)) / 3;

				red += _red * mask[u][v];
				green += _green * mask[u][v];
				blue += _blue * mask[u][v];
			}
		}
		//std::cout << "o_red = " << o_red << " red = " << (unsigned char) ((int) (red * 1/16)) << std::endl;
		sc_dt::sc_uint<36> o_rgb;
		o_rgb.range(11, 0) = (red);
		o_rgb.range(23, 12) = (green);
		o_rgb.range(35, 24) =  (blue);
#ifndef NATIVE_SYSTEMC
		{
			HLS_DEFINE_PROTOCOL("output");
			o_result.put(o_rgb);
			wait();
		}
#else
		o_result.write(total);
#endif
	}
}
