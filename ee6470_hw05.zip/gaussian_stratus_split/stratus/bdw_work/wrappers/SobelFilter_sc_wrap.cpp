/****************************************************************************
*
*  Copyright (c) 2015, Cadence Design Systems. All Rights Reserved.
*
*  This file contains confidential information that may not be
*  distributed under any circumstances without the written permision
*  of Cadence Design Systems.
*
****************************************************************************/
/****************************************************************************
*
* This file is used to wrap the three different versions of the DUT
* block called "SobelFilter". By default, it will include the behavioral
* model. Otherwise, it will include the RTL C++ or the RTL Verilog
* depending on the definition of either of "RTL" or "COSIM".
*
****************************************************************************/


#include	"SobelFilter_sc_wrap.h"
#include	"SobelFilter_sc_foreign.h"

// The following threads are used to connect structured ports to the actual
// RTL ports

void SobelFilter_wrapper::InitInstances(  )
{
	
            
    SobelFilter0 = new SobelFilter( "SobelFilter" );

    SobelFilter0->i_clk(i_clk);
    SobelFilter0->i_rst(i_rst);
    SobelFilter0->i_rgb_busy(i_rgb.busy);
    SobelFilter0->i_rgb_vld(i_rgb.vld);
    SobelFilter0->i_rgb_data(i_rgb.data);
    SobelFilter0->o_R_busy(o_R.busy);
    SobelFilter0->o_R_vld(o_R.vld);
    SobelFilter0->o_R_data(o_R.data);
    SobelFilter0->o_G_busy(o_G.busy);
    SobelFilter0->o_G_vld(o_G.vld);
    SobelFilter0->o_G_data(o_G.data);
    SobelFilter0->o_B_busy(o_B.busy);
    SobelFilter0->o_B_vld(o_B.vld);
    SobelFilter0->o_B_data(o_B.data);

}

void SobelFilter_wrapper::InitThreads()
{
    
}

void SobelFilter_wrapper::DeleteInstances()
{
    if (SobelFilter0)
    {
        delete SobelFilter0;
        SobelFilter0 = 0;
    }
}

