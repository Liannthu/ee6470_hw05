	if ( esc_trace_is_enabled( esc_trace_vcd ) ) {
		if ( SobelFilter0 != NULL ) {
			esc_trace_signal( &SobelFilter0->i_clk, ( std::string(name()) + std::string( ".SobelFilter.i_clk" ) ).c_str(), esc_trace_vcd );
			esc_trace_signal( &SobelFilter0->i_rst, ( std::string(name()) + std::string( ".SobelFilter.i_rst" ) ).c_str(), esc_trace_vcd );
			esc_trace_signal( &SobelFilter0->i_rgb.busy, ( std::string(name()) + std::string( ".SobelFilter.i_rgb.busy" ) ).c_str(), esc_trace_vcd );
			esc_trace_signal( &SobelFilter0->i_rgb.vld, ( std::string(name()) + std::string( ".SobelFilter.i_rgb.vld" ) ).c_str(), esc_trace_vcd );
			esc_trace_signal( &SobelFilter0->i_rgb.data, ( std::string(name()) + std::string( ".SobelFilter.i_rgb.data" ) ).c_str(), esc_trace_vcd );
			esc_trace_signal( &SobelFilter0->o_R.busy, ( std::string(name()) + std::string( ".SobelFilter.o_R.busy" ) ).c_str(), esc_trace_vcd );
			esc_trace_signal( &SobelFilter0->o_R.vld, ( std::string(name()) + std::string( ".SobelFilter.o_R.vld" ) ).c_str(), esc_trace_vcd );
			esc_trace_signal( &SobelFilter0->o_R.data, ( std::string(name()) + std::string( ".SobelFilter.o_R.data" ) ).c_str(), esc_trace_vcd );
			esc_trace_signal( &SobelFilter0->o_G.busy, ( std::string(name()) + std::string( ".SobelFilter.o_G.busy" ) ).c_str(), esc_trace_vcd );
			esc_trace_signal( &SobelFilter0->o_G.vld, ( std::string(name()) + std::string( ".SobelFilter.o_G.vld" ) ).c_str(), esc_trace_vcd );
			esc_trace_signal( &SobelFilter0->o_G.data, ( std::string(name()) + std::string( ".SobelFilter.o_G.data" ) ).c_str(), esc_trace_vcd );
			esc_trace_signal( &SobelFilter0->o_B.busy, ( std::string(name()) + std::string( ".SobelFilter.o_B.busy" ) ).c_str(), esc_trace_vcd );
			esc_trace_signal( &SobelFilter0->o_B.vld, ( std::string(name()) + std::string( ".SobelFilter.o_B.vld" ) ).c_str(), esc_trace_vcd );
			esc_trace_signal( &SobelFilter0->o_B.data, ( std::string(name()) + std::string( ".SobelFilter.o_B.data" ) ).c_str(), esc_trace_vcd );
		}
	}
	if ( esc_trace_is_enabled( esc_trace_fsdb ) ) {
		if ( SobelFilter0 != NULL ) {
			esc_trace_signal( &SobelFilter0->i_clk, ( std::string(name()) + std::string( ".SobelFilter.i_clk" ) ).c_str(), esc_trace_fsdb );
			esc_trace_signal( &SobelFilter0->i_rst, ( std::string(name()) + std::string( ".SobelFilter.i_rst" ) ).c_str(), esc_trace_fsdb );
			esc_trace_signal( &SobelFilter0->i_rgb.busy, ( std::string(name()) + std::string( ".SobelFilter.i_rgb.busy" ) ).c_str(), esc_trace_fsdb );
			esc_trace_signal( &SobelFilter0->i_rgb.vld, ( std::string(name()) + std::string( ".SobelFilter.i_rgb.vld" ) ).c_str(), esc_trace_fsdb );
			esc_trace_signal( &SobelFilter0->i_rgb.data, ( std::string(name()) + std::string( ".SobelFilter.i_rgb.data" ) ).c_str(), esc_trace_fsdb );
			esc_trace_signal( &SobelFilter0->o_R.busy, ( std::string(name()) + std::string( ".SobelFilter.o_R.busy" ) ).c_str(), esc_trace_fsdb );
			esc_trace_signal( &SobelFilter0->o_R.vld, ( std::string(name()) + std::string( ".SobelFilter.o_R.vld" ) ).c_str(), esc_trace_fsdb );
			esc_trace_signal( &SobelFilter0->o_R.data, ( std::string(name()) + std::string( ".SobelFilter.o_R.data" ) ).c_str(), esc_trace_fsdb );
			esc_trace_signal( &SobelFilter0->o_G.busy, ( std::string(name()) + std::string( ".SobelFilter.o_G.busy" ) ).c_str(), esc_trace_fsdb );
			esc_trace_signal( &SobelFilter0->o_G.vld, ( std::string(name()) + std::string( ".SobelFilter.o_G.vld" ) ).c_str(), esc_trace_fsdb );
			esc_trace_signal( &SobelFilter0->o_G.data, ( std::string(name()) + std::string( ".SobelFilter.o_G.data" ) ).c_str(), esc_trace_fsdb );
			esc_trace_signal( &SobelFilter0->o_B.busy, ( std::string(name()) + std::string( ".SobelFilter.o_B.busy" ) ).c_str(), esc_trace_fsdb );
			esc_trace_signal( &SobelFilter0->o_B.vld, ( std::string(name()) + std::string( ".SobelFilter.o_B.vld" ) ).c_str(), esc_trace_fsdb );
			esc_trace_signal( &SobelFilter0->o_B.data, ( std::string(name()) + std::string( ".SobelFilter.o_B.data" ) ).c_str(), esc_trace_fsdb );
		}
	}
